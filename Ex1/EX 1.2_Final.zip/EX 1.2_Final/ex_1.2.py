import random as rd
import pandas as pd
import matplotlib.pyplot as plt

M = 10000000
p = 0.16
s = (1-p)/26
files='./'

def FreqDistn(strlist):
    strlist = pd.DataFrame(strlist, columns=["x"]).groupby('x').size().sort_values(ascending=False).to_dict()
    return strlist

def zipf(file):
    with open(files+file, 'r', encoding="utf8") as file:
        str = file.read()
        tokens = str.split(' ')
        tokens = [word for word in tokens if word.isalpha()]
        b=[]
        ranks=0
        rank=[]
        fdist = FreqDistn(tokens)
        for word,count in fdist.items():
            a=[word]
            #print(a)
            b.append(count)
            ranks+=1
            rank.append(ranks)
    #print(b)
    #print(rank)
    plt.loglog(rank,b)
    plt.ylabel('frequency(f)', fontsize=14, fontweight='bold')
    plt.xlabel('rank(r)', fontsize=14, fontweight='bold')
    plt.grid(True)
    plt.show()
    '''plt.savefig('zipfs.png')'''

def createMiller():
	f = open('miller.txt','w')
	for i in range(M):
		r = rd.randrange(0,100,1)/100
		if r<=p:
			c =' '
		else:
			n = int((r-p)/s)+1
			c = chr(n+96)
		f.write(c)
	f.close()



if __name__ == '__main__':
    zipf('miller.txt')