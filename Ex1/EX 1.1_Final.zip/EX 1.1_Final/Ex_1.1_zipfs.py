import pandas as pd
from random import randint
import matplotlib
import matplotlib.pyplot as plt
import os
from prettytable import PrettyTable
files = 'E:/SU/Semester 1 Sum-19/SNLP/ASSIGNMENT/1/FINAL SUBMISSION EX 1.1/exercise1_corpora/corpora/'

def FreqDistn(strlist):
    strlist = pd.DataFrame(strlist, columns=["x"]).groupby('x').size().sort_values(ascending=False).to_dict()
    return strlist

def ex_1d(file,t):
    file_name=file
    with open(files+file, 'r', encoding="utf8") as file:
        tokens = file.read()
        tokens = [word for word in tokens if word.isalpha()]
        count = 0
        number_of_total_character=0
        lst=[]
        fdist = FreqDistn(tokens)

        for char in fdist.items():
            number_of_total_character+=char[1]

        for char in fdist.items():
            if (char[0] >= "A" and char[0] <= 'Z') or (char[0] >= 'a' and char[0] <= 'z'):
                if count<10:
                    char = list(char)
                    char[1] = round(char[1]/number_of_total_character,4)
                    char = tuple(char)
                    lst.append(char)
                    count += 1
        t.add_row([file_name,lst])

def ex_1c(file):
    file_name=file
    with open(files+file, 'r', encoding="utf8") as file:
        tokens = file.read()
        tokens = [word for word in tokens if word.isalpha()]
        freq=[]
        ranks=0
        rank=[]
        fdist = FreqDistn(tokens)
        for char,count in fdist.items():
            if (char>="A" and char<='Z') or (char>='a' and char<='z'):
                freq.append(count)
                ranks += 1
                rank.append(ranks)

    plt.loglog(rank, freq)
    plt.ylabel('frequency(f)', fontsize=14, fontweight='bold')
    plt.xlabel('rank(r)', fontsize=14, fontweight='bold')
    plt.grid(True)
    plt.savefig(file_name +'_Character_level'+ '.png')
    plt.show()

def ex_1b(file,t):
    file_name=file
    with open(files+file, 'r', encoding="utf8") as file:
        str = file.read()
        tokens = str.split(' ')
        tokens = [word for word in tokens if word.isalpha()]
        b=[]
        index=0
        random_selection=[]
        words_len_1=0
        sum=0
        sum_len_1=0
        rank=[]
        fdist = FreqDistn(tokens)
        for word, count in fdist.items():
            if index < 10:
                sum += len(word)
            if count==1:
                words_len_1 += 1
                if words_len_1 == 1:
                    start = index
            index += 1
        index = 0

        mean_most_freq = sum / 10

        for index in range(10):
            random_selection.append(randint(1, words_len_1) + start)
        random_selection.sort()
        index=0
        for word,count in fdist.items():
            for i in range(10):
                if index == random_selection[i]:
                    sum_len_1 = sum_len_1 + len(word)
            index += 1
        mean_least_freq = sum_len_1 / 10
        t.add_row([file_name,mean_most_freq,mean_least_freq])


def ex_1a(file):
    file_name = file
    with open(files + file, 'r', encoding="utf8") as file:
        str = file.read()
        tokens = str.split(' ')
        tokens = [word for word in tokens if word.isalpha()]
        freq = []
        ranks = 0
        rank = []
        fdist = FreqDistn(tokens)
        for word, count in fdist.items():
            a = [word]
            freq.append(count)
            ranks += 1
            rank.append(ranks)

    plt.loglog(rank, freq)
    plt.ylabel('frequency(f)', fontsize=14, fontweight='bold')
    plt.xlabel('rank(r)', fontsize=14, fontweight='bold')
    plt.grid(True)
    plt.savefig(file_name + '_Word_level' + '.png')
    plt.show()

def zipf_all():
    for i in range(4):
        if i==0:
            print('--------------------------Exercise 1.1a--------------------------')
            print('Showing 6 figures for word level...')
            for file in os.listdir(files):
                ex_1a(file)
        elif i==1:
            print('--------------------------Exercise 1.1b--------------------------')
            print('Generating table 1.1_b...')
            t = PrettyTable()
            t.title = 'Comparison of Length of Most and Least Frequent Words'
            t.field_names = ['Corpus Name', 'Mean of Length of 10 Most Frequent Words', 'Mean of Length of 10 Randomly Chosen Words with Frequency 1']
            for file in os.listdir(files):
                ex_1b(file,t)
            print(t)
        elif i==2:
            print('--------------------------Exercise 1.1c--------------------------')
            print('Showing 6 figures for character level...')
            print('\n')
            for file in os.listdir(files):
                ex_1c(file)
        elif i==3:
            print('--------------------------Exercise 1.1d--------------------------')
            print('Generating table 1.1_d...')
            t = PrettyTable()
            t.title = 'Relative Frequency of Most Frequent 10 Characters in Each Corpus'
            t.field_names = ['Corpus Name', 'Top 10 Most Frequent Characters and Their Relative Frequency']
            for file in os.listdir(files):
                ex_1d(file,t)
            print(t)
zipf_all()