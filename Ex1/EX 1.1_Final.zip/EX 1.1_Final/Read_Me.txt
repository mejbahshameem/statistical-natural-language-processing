To execute the code please give the location of the directory where your corpora folder(containing only six corpus file)
is located.

Replace the adress mentioned in the variable 'files' in 'Ex_1.1.py' by the address of your corpora directory.

Thank you!!  