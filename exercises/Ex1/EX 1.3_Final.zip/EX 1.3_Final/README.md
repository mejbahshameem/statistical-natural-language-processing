#####*Implementation of investigation of relationship between the corpus size and vocabulary size in multilingual text corpus.*

####Install requirements
`pip install -r requirements.txt`

####Usage
You can launch the script to reproduce the figure directly from *vocabulary_growth.py*

You need to have corpora folder in the same directory with the *vocabulary_growth.py*
<br>
OR<br>
Import method *plot_relationship* and set keyword argument path to directory where corpora files are located

The script will save plotted figure as .png file