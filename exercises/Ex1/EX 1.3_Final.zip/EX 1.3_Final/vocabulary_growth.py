import re
from collections import Counter
from matplotlib import pyplot as plt


class CorporaHandler:
    def __init__(self, text):
        self.text_tokens = self.tokenize(text)
        self.corpora_size = len(self.text_tokens)
        self.vocabulary_size = len(set(self.text_tokens))
        self.vocabulary = None

    @staticmethod
    def tokenize(text):
        '''

        :param text: plain text of language corpus, string
        :return: list of tokens, list of strings
        '''

        return re.findall(r'\b\w+', re.sub(r'\d', '', text))

    def get_vocabulary(self):
        self.vocabulary = Counter(self.text_tokens)
        return self.vocabulary

    def calculate_statistics(self, partition=100):
        '''

        :param partition: percent of corpora tokens, float
        :return: number of tokens in text partition, average vocabulary size
        for all text samples which are P% of full text, (int, int)
        '''
        if partition == 100:
            return self.corpora_size, self.vocabulary_size
        else:
            # calculate
            part_size = int(self.corpora_size * partition / 100)
            samples = self.corpora_size - part_size + 1

            vocabulary = Counter(self.text_tokens[:part_size])
            average_vocabulary_size = len(vocabulary) / samples

            for n in range(1, samples):
                vocabulary[self.text_tokens[n-1]] -= 1
                if vocabulary[self.text_tokens[n-1]] == 0:
                    vocabulary.pop(self.text_tokens[n-1])
                vocabulary[self.text_tokens[n + part_size - 1]] += 1
                average_vocabulary_size += len(vocabulary) / samples

            return part_size, round(average_vocabulary_size)


def plot_relationship(path='corpora'):
    '''

    :param path: path to the directory where corpora files are located, string
    :return: void, plot the figure and save as .png file
    '''
    languages = [('.fi', 'Finnish'), ('.de', 'German'), ('.bg', 'Bulgarian'),
                 ('.el', 'Greek'), ('.mt', 'Maltese'), ('.fr', 'French')]

    plt.figure(1)
    plt.axis([0, 1000, 0, 75000])
    plt.ylabel('Vocabulary size')
    plt.xlabel('Corpora size, thousands')

    for i, lang in enumerate(languages, start=1):

        with open(path + '/corpus' + lang[0], 'r', encoding='UTF-8') as file:
            corpora = file.read()

        handler = CorporaHandler(corpora)
        print('{}: {}'.format(lang, handler.calculate_statistics()))

        percentages = [0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100]
        partition_size = []
        vocab_size = []
        for percent in percentages:
            stat = handler.calculate_statistics(partition=percent)
            partition_size.append(stat[0] / 1000)
            vocab_size.append(stat[1])

        plt.plot(partition_size, vocab_size, label=lang[1])

    plt.legend(loc='upper left', shadow=True)
    plt.savefig('vocab_growth.png')
    plt.show()


if __name__ == '__main__':
    plot_relationship()
